<?php

$body_class = 'blog';

include 'inc/header.php';
?>
		<section class="block-blog">
			<div class="grid">
				
				<div class="blog-grid">
					<a href="entry.php">
						<div class="entry-preview">
							<img src="images/blog/0.jpg" alt="">
							<div class="entry-date">02.02.02</div>
						</div>
						<h4>Вот каких предложений о работе нам не хватает</h4>
						<p>Объявления, от которых на стенах краска сворачивается.</p>
					</a>

					<a href="entry.php">
						<div class="entry-preview">
							<img src="images/blog/1.jpg" alt="">
							<div class="entry-date">02.02.02</div>
						</div>
						<h4>«Вырастил» миллионный долг</h4>
						<p>Житель Мелекесского района запоздало ищет возможности расплатиться с банком и пенсионным фондом.</p>
					</a>

					<a href="entry.php">
						<div class="entry-preview">
							<img src="images/blog/2.jpg" alt="">
							<div class="entry-date">02.02.02</div>
						</div>
						<h4>Вот каких предложений о работе нам не хватает</h4>
						<p>Объявления, от которых на стенах краска сворачивается.</p>
					</a>

					<a href="entry.php">
						<div class="entry-preview">
							<img src="images/blog/3.jpg" alt="">
							<div class="entry-date">02.02.02</div>
						</div>
						<h4>«Вырастил» миллионный долг</h4>
						<p>Житель Мелекесского района запоздало ищет возможности расплатиться с банком и пенсионным фондом.</p>
					</a>
				</div>

			</div>
		</section>
<?php
include 'inc/footer.php';
?>